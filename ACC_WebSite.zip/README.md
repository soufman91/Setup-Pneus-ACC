# Déploiement GitHub + Render
1. Uploadez tous les fichiers dans un repo GitHub.
2. Activez GitHub Pages (branch main, root).
3. Sur Render > New Static Site > Choisir le repo.
4. Build command: (vide), Publish directory: '/'.
